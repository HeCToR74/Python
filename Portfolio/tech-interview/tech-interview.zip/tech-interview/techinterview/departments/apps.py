from django.apps import AppConfig


class DepartmentsConfig(AppConfig):
    name = 'departments'
