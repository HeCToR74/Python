#!/bin/bash

echo "bucketName = 42" >> .env
echo "region = 42" >> .env
echo "accessKeyId = 42" >> .env
echo "secretAccessKey = 42" >> .env
